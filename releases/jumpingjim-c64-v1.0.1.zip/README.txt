Jumping Jim - Commodore 64 v1.0.1

LOAD"*",8,1 and RUN (or open the .d64 in VICE).
Keys: O/Z left, P/X right, Q/SPACE jump. Joystick in port 2 or 1.

Original game by roman126 - https://roman126.itch.io/jumping-jim-zx-spectrum-next
C64 port by Carlos Zayas (AI-assisted) - https://github.com/czayas/jumpingjim
